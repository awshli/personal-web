<!doctype html>
<html class="no-js" lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Page not found &#8211; A Digital &amp; Creative طراحی وب Development Agency</title>
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.wordpressboss.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.5"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://www.wordpressboss.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.6' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='animate-css'  href='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/css/libs/animate.min.css?ver=140220170928' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/css/libs/font-awesome.min.css?ver=140220170928' type='text/css' media='all' />
<link rel='stylesheet' id='theme-fonts-css'  href='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/css/front/fonts.css?ver=140220170928' type='text/css' media='all' />
<link rel='stylesheet' id='theme-front-css'  href='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/css/front/skin.css?ver=140220170928' type='text/css' media='all' />
<link rel='stylesheet' id='theme-images-css'  href='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/css/front/images.css?ver=140220170928' type='text/css' media='all' />
<script type='text/javascript' src='http://www.wordpressboss.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.6'></script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var fwAjaxUrl = "\/wp-admin\/admin-ajax.php";
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/plugins/unyson/framework/static/js/fw-form-helpers.js?ver=4.9.5'></script>
<link rel='https://api.w.org/' href='http://www.wordpressboss.com/wp-json/' />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.wordpressboss.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.5" />
<meta name="generator" content="Powered by Slider Revolution 5.4.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>
</head>
<body class="error404 go-top fixed-header sidebar-right parallax-footer">

		
		
	<!--
		Main wrapper
	-->
	<div id="wrap">
	
		<!--
			Page header
		-->
		<header class="headroom" id="header">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
					
										<a href="http://www.wordpressboss.com" class="logo logo-image"><img style="" src="" data-no-retina alt="A Digital &amp; Creative طراحی وب Development Agency &ndash; Based In dhaka Bangladesh" /></a>
										
									<!--
				Navigation
			-->
							<nav id="header-nav"  class="dl-menuwrapper logo-style-image" data-back-label="Back">
						
				<!--
					Toggle menu for mobile devices
					this element is hidden for desktop and large monitors
				-->
				<a href="javascript:;" id="mobile-menu-toggler" class="dl-trigger"><span>Toggle Menu</span></a>
			
				<ul id="header-menu" class="dl-menu"><li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-47 level-0"><a class="menu-item-href"  href="http://www.wordpressboss.com/" ><span class="line_wrap"><span class="line"></span>خانه Agency</span></a></li>
<li id="menu-item-46" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-46 level-0"><a class="menu-item-href"  href="http://www.wordpressboss.com/home-app-showcase/" ><span class="line_wrap"><span class="line"></span>خانه App</span></a></li>
<li id="menu-item-45" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-45 level-0"><a class="menu-item-href"  href="http://www.wordpressboss.com/home-personal-page/" ><span class="line_wrap"><span class="line"></span>خانه Personal</span></a></li>
<li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44 level-0 blog-menu-item"><a class="menu-item-href"  href="http://www.wordpressboss.com/blog/" ><span class="line_wrap"><span class="line"></span>وبلاگ</span></a></li>
<li id="menu-item-48" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-48 level-0 drop"><a class="menu-item-href"  ><span class="line_wrap"><span class="line"></span>Pages<i class="submenu-icon"></i></span></a>
<ul class="sub-menu dl-submenu appear-on-right">
	<li id="menu-item-63" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-63 level-1"><a class="menu-item-href"  href="http://www.wordpressboss.com/example-scroll-header/" >Example &#8211; Scroll Header</a></li>
	<li id="menu-item-62" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62 level-1"><a class="menu-item-href"  href="http://www.wordpressboss.com/example-simple-header/" >Example &#8211; Simple Header</a></li>
	<li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-60 level-1"><a class="menu-item-href"  href="http://www.wordpressboss.com/example-left-sidebar/" >Example &#8211; Left Sidebar</a></li>
	<li id="menu-item-59" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-59 level-1"><a class="menu-item-href"  href="http://www.wordpressboss.com/example-typography/" >Example &#8211; Typography</a></li>
	<li id="menu-item-64" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-64 level-1 drop"><a class="menu-item-href " >Right Menu<i class="submenu-icon"></i></a>
	<ul class="sub-menu dl-submenu appear-on-right">
		<li id="menu-item-66" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-66 level-2"><a class="menu-item-href"  href="http://google.com" >Link 1</a></li>
		<li id="menu-item-67" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-67 level-2"><a class="menu-item-href"  href="http://yahoo.com" >Link 2</a></li>
		<li id="menu-item-68" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-68 level-2"><a class="menu-item-href"  href="http://themeforest.net/user/wplab/portfolio/?ref=wplab" >Link 3</a></li>
	</ul>
</li>
	<li id="menu-item-65" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-65 level-1 drop"><a class="menu-item-href " >Left Menu<i class="submenu-icon"></i></a>
	<ul class="sub-menu dl-submenu appear-on-left">
		<li id="menu-item-69" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-69 level-2"><a class="menu-item-href"  href="http://google.com" >Link 1</a></li>
		<li id="menu-item-70" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70 level-2"><a class="menu-item-href"  href="http://yahoo.com" >Link 2</a></li>
		<li id="menu-item-71" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-71 level-2"><a class="menu-item-href"  href="http://themeforest.net/user/wplab/portfolio/?ref=wplab" >Link 3</a></li>
	</ul>
</li>
</ul>
</li>
</ul>			
			</nav>
								
					</div>
				</div>
			</div>
		</header>
		
		<!--
			Content section area
		-->
		<div id="content-wrapper" style="">
<div class="container">
	<div class="row">
	
		<!--
			Page 404
		-->
	
		<div id="content" class="col-md-12 page-error-404">

						
				<h1 style="text-align: center;">Error <span>404</span></h1><p style="text-align: center;">Page not found</p>			
						
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<form action="http://www.wordpressboss.com" method="get">
	<input type="search" name="s" value="" placeholder="Search..." />
</form>				</div>
			</div>

		</div>
	
	</div><!-- end of row -->
</div><!-- end of container -->

		</div><!-- End of content wrapper -->
		
		<!--
			Footer
		-->
		<footer id="footer">
		
							<div id="footer-widgets" class="footer-columns-1">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="widgets">
									<div id="wproto_logo_widget-2" class="widget wproto_logo_widget"><div class="widget-content">

	
<a href="http://www.wordpressboss.com" class="footer-logo"><img src="//www.wordpressboss.com/wp-content/uploads/2015/09/logo.png" data-at2x="//www.wordpressboss.com/wp-content/uploads/2015/09/logo@2x.png" alt="" width="170" /></a>

	<div>
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>	</div>

<div class="clearfix"></div></div></div><div id="mc4wp_form_widget-2" class="widget widget_mc4wp_form_widget"><div class="widget-content"><script type="text/javascript">(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();
</script><!-- MailChimp for WordPress v4.2 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-382" method="post" data-id="382" data-name="Default sign-up form" ><div class="mc4wp-form-fields"><input type="email" name="EMAIL" placeholder="Your Email Address..." required /><input type="submit" /></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1522864802" /><input type="hidden" name="_mc4wp_form_id" value="382" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div></form><!-- / MailChimp for WordPress Plugin --><div class="clearfix"></div></div></div><div id="wproto_social_icons_widget-2" class="widget wproto_social_icons_widget"><div class="widget-content">
					<div class="social-icons">
					<a href="http://linkedin.com" target="_blank"><i class="fa fa-linkedin"></i></a><a href="http://youtube.com" target="_blank"><i class="fa fa-youtube-play"></i></a><a href="http://vimeo.com" target="_blank"><i class="fa fa-vimeo"></i></a><a href="http://facebook.com" target="_blank"><i class="fa fa-facebook"></i></a><a href="http://twitter.com" target="_blank"><i class="fa fa-twitter"></i></a>				</div>
				
<div class="clearfix"></div></div></div>								</div>
							</div>
						</div>
					</div>
				</div>
				
						<div id="bottom-bar">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<p>©2015 Creative Agency <a>Unicum</a></p><p>طراحیed by <a href="http://themeforest.net/user/themefire/?ref=wplab">ThemeFire</a> / Developed by <a href="http://themeforest.net/user/wplab/?ref=wplab">WPlab.Pro</a></p><p>Only for <a href="http://themeforest.net/user/wplab/portfolio/?ref=wplab">Envato Market</a></p>						</div>
					</div>
				</div>
			</div>
					
		</footer>
	
	</div><!-- End of primary wrapper -->
	
		
	<script type="text/javascript">(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script><script type='text/javascript' src='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/js/all_in_one_libs.min.js?ver=140220170928'></script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/js/libs/jquery.youtubebackground.js?ver=140220170928'></script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/js/libs/jquery.dlmenu.js?ver=140220170928'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wprotoEngineVars = {"ajaxurl":"http:\/\/www.wordpressboss.com\/wp-admin\/admin-ajax.php","strSuccess":"Success","strError":"Error"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/themes/wplab-unicum/js/front.min.js?ver=140220170928'></script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-includes/js/wp-embed.min.js?ver=4.9.5'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */
</script>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/plugins/mailchimp-for-wp/assets/js/forms-api.min.js?ver=4.2'></script>
<!--[if lte IE 9]>
<script type='text/javascript' src='http://www.wordpressboss.com/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.2'></script>
<![endif]-->
</body>
</html>